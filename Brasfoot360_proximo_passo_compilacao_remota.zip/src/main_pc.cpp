#include <iostream>
#include "game.h"

int main() {
    Team home = {"CR Flamengo", 82, 75};
    Team away = {"SE Palmeiras", 81, 76};
    unsigned int seed = 20261016u;
    Score s = simulate_match(home, away, &seed);

    std::cout << "BRASFOOT 360 - prototipo\n\n";
    std::cout << home.name << " " << s.home << " x " << s.away
              << " " << away.name << "\n";
    std::cout << "\nEste e um teste de logica, nao o executavel de Xbox 360.\n";
    return 0;
}
