/*
 * Front-end experimental para LibXenon.
 * A API de console varia entre distribuicoes da toolchain. Este arquivo usa
 * console_init/console_set_colors/console_clear/console_puts/console_close;
 * confirme os nomes nos headers da sua instalacao antes de compilar.
 */
#include <stdio.h>
#include <console/console.h>
#include "game.h"

int main() {
    Team home = {"CR Flamengo", 82, 75};
    Team away = {"SE Palmeiras", 81, 76};
    unsigned int seed = 20261016u;
    Score s = simulate_match(home, away, &seed);

    console_init();
    console_set_colors(CONSOLE_COLOR_WHITE, CONSOLE_COLOR_BLACK);
    console_clear();
    console_puts("BRASFOOT 360 - PROTOTIPO\n\n");
    console_puts(home.name);
    console_puts(" ");
    char score[32];
    snprintf(score, sizeof(score), "%d x %d ", s.home, s.away);
    console_puts(score);
    console_puts(away.name);
    console_puts("\n\nAperte qualquer botao para sair (entrada ainda nao ligada).\n");

    // Mantem a tela visivel. Para sair, reinicie o console.
    for (;;) { }
    console_close();
    return 0;
}
