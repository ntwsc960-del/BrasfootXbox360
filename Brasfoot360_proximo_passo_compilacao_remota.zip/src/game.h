#ifndef BRASFOOT360_GAME_H
#define BRASFOOT360_GAME_H

struct Team {
    const char* name;
    int attack;
    int defense;
};

struct Score {
    int home;
    int away;
};

unsigned int game_random(unsigned int* state);
Score simulate_match(const Team& home, const Team& away, unsigned int* state);

#endif
