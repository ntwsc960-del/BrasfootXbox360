#include "game.h"

unsigned int game_random(unsigned int* state) {
    // PRNG simples e portavel; nao depende de rand()/time().
    *state = (*state * 1664525u) + 1013904223u;
    return *state;
}

static int goals_for(int attack, int defense, int home_bonus, unsigned int* state) {
    int chance = 38 + (attack - defense) / 3 + home_bonus;
    if (chance < 12) chance = 12;
    if (chance > 68) chance = 68;

    int goals = 0;
    for (int i = 0; i < 5; ++i) {
        unsigned int roll = game_random(state) % 100u;
        int threshold = chance / (i + 1);
        if ((int)roll < threshold) ++goals;
    }
    return goals;
}

Score simulate_match(const Team& home, const Team& away, unsigned int* state) {
    Score result;
    result.home = goals_for(home.attack, away.defense, 6, state);
    result.away = goals_for(away.attack, home.defense, 0, state);
    return result;
}
