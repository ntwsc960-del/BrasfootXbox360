# Xbox Series Experience 360 — native xSDK starter

This revision removes the SDL dependency and uses the xSDK APIs directly for:
- Xbox 360 controller input (`XamInputGetState`);
- 720p presentation (`xsdk_present_*`);
- GPU target/resolve (`xsdk_gpu_*`);
- bitmap-font text (`xsdk_text_*`).

It is a **starter prototype**, not a finished dashboard replacement. It does not scan or launch games, transfer files, connect to cloud gaming, or authenticate a Microsoft account. It does not modify Aurora, DashLaunch, or NAND.

## Build requirements

A Windows 10/11 PC with WSL 2 and Debian is the documented route in the xSDK guide. An Android phone alone is not a straightforward supported build environment for this toolchain.

Official xSDK guide:
https://github.com/xenosworks/xsdk/blob/main/docs/GETTING_STARTED.md

## Build steps

Follow the xSDK guide through the steps to install Debian/WSL, build the `powerpc-xsdk-elf` toolchain, and build xSDK itself. Then, inside Debian:

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$HOME/xsdk/cmake/xsdk.cmake" \
  -DXSDK_TOOLCHAIN="$HOME/xsdk-gcc" \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build
```

Expected output if the toolchain and source APIs match:
`build/XboxSeriesExperience360.xex`

Do not rename an ELF or any other file to `.xex`. The `xsdk_add_xex()` build rule packages it.

## Controller

- D-pad up/down: select menu items or move sections.
- D-pad left/right and LB/RB: change sections.
- A: activate.
- B: return to Home.
- Start: show/hide hints.
- Back: exit to the dashboard.

## Status and limitations

- Source files are prepared but **not compiled or tested here**.
- A successful build is not the same as hardware validation. Test the resulting XEX on an RGH/JTAG console, starting from a separate folder.
- Cloud gaming, PC transfer, scanning/launching games, persistent settings, artwork and proper filled panels are not implemented yet.
- If the build fails, save the full compiler output; the exact error is needed to make a grounded fix.
