// Xbox Series Experience 360 — first native xSDK build.
// No SDL dependency: controller input, display and text use xSDK directly.
// This is an experimental dashboard-style application, not a replacement for Aurora.

#include <cstdint>
#include <cstdio>
#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/present.h"
#include "xsdk/splash.h"
#include "xsdk/text.h"

namespace {
constexpr uint32_t kBuffers = 2;
constexpr uint32_t kSwapInterval = 1;
constexpr uint32_t kBeginTimeoutMs = 5000;
constexpr uint32_t kSplashMs = 1000;

enum class Page : int { Home, Library, Connect, Cloud, Profile, Settings, Count };

struct AppState {
    Page page = Page::Home;
    int selected = 0;
    bool running = true;
    bool showHint = true;
    char notice[112] = "PROTOTIPO NATIVO - FUNCOES EM DESENVOLVIMENTO";
};

constexpr uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
    return 0xFF000000u | (uint32_t(r) << 16) | (uint32_t(g) << 8) | uint32_t(b);
}

void setNotice(AppState& app, const char* message) {
    std::snprintf(app.notice, sizeof(app.notice), "%s", message);
}

const char* pageTitle(Page page) {
    switch (page) {
        case Page::Home: return "INICIO";
        case Page::Library: return "BIBLIOTECA DE JOGOS";
        case Page::Connect: return "CONECTAR AO PC";
        case Page::Cloud: return "JOGOS NA NUVEM";
        case Page::Profile: return "PERFIL LOCAL";
        case Page::Settings: return "CONFIGURACOES";
        default: return "INICIO";
    }
}

void changePage(AppState& app, int delta) {
    int page = static_cast<int>(app.page);
    const int count = static_cast<int>(Page::Count);
    page = (page + delta + count) % count;
    app.page = static_cast<Page>(page);
    app.selected = 0;
}

void activate(AppState& app) {
    switch (app.page) {
        case Page::Home:
            switch (app.selected) {
                case 0: app.page = Page::Library; break;
                case 1: app.page = Page::Connect; break;
                case 2: app.page = Page::Cloud; break;
                case 3: app.page = Page::Settings; break;
                default: break;
            }
            app.selected = 0;
            break;
        case Page::Library:
            setNotice(app, "SCANNER DE JOGOS AINDA NAO IMPLEMENTADO");
            break;
        case Page::Connect:
            setNotice(app, "TRANSFERENCIA DE ARQUIVOS AINDA NAO IMPLEMENTADA");
            break;
        case Page::Cloud:
            setNotice(app, "SEM CLIENTE DE CLOUD GAMING NESTE PROTOTIPO");
            break;
        case Page::Profile:
            setNotice(app, "PERFIL LOCAL DE DEMONSTRACAO - SEM LOGIN");
            break;
        case Page::Settings:
            app.showHint = !app.showHint;
            setNotice(app, "DICA VISUAL ALTERADA");
            break;
        default: break;
    }
}

void drawText(int x, int y, uint32_t scale, uint32_t argb, const char* text) {
    xsdk_text_draw(x, y, scale, argb, text);
}

void drawPage(const AppState& app) {
    const uint32_t white = rgb(242, 246, 250);
    const uint32_t muted = rgb(144, 157, 174);
    const uint32_t green = rgb(16, 210, 105);
    const uint32_t blue = rgb(75, 155, 255);
    const uint32_t purple = rgb(184, 117, 255);
    const uint32_t amber = rgb(255, 185, 70);
    const uint32_t red = rgb(235, 75, 82);

    drawText(28, 20, 2, green, "X");
    drawText(62, 18, 2, white, "SERIES EXPERIENCE 360");
    drawText(62, 43, 1, muted, "INTERFACE NATIVA EXPERIMENTAL");
    drawText(930, 28, 1, muted, "RGH/JTAG");
    drawText(28, 88, 2, white, pageTitle(app.page));
    drawText(28, 120, 1, green, "--------------------------------------------------------------");

    if (app.page == Page::Home) {
        drawText(28, 160, 3, white, "SEU XBOX. DO SEU JEITO.");
        drawText(28, 208, 1, muted, "UMA CENTRAL EXPERIMENTAL PARA JOGOS E APLICATIVOS");
        drawText(28, 258, 2, green, "ACESSO RAPIDO");
        const char* items[] = {
            "01  BIBLIOTECA DE JOGOS",
            "02  CONECTAR AO PC",
            "03  JOGOS NA NUVEM",
            "04  CONFIGURACOES"
        };
        const uint32_t accents[] = {green, blue, purple, amber};
        for (int i = 0; i < 4; ++i) {
            const int y = 302 + i * 54;
            drawText(42, y, 2, app.selected == i ? accents[i] : white, items[i]);
            if (app.selected == i) drawText(20, y, 2, green, ">");
        }
        drawText(28, 548, 1, muted, "USE DIRECIONAL; A ABRE; B VOLTA; BACK SAI");
    } else if (app.page == Page::Library) {
        drawText(28, 158, 2, green, "SUA COLECAO");
        drawText(28, 208, 1, white, "BIBLIOTECA VISUAL");
        drawText(28, 244, 1, muted, "Leitura de pastas e lancamento de jogos ainda nao implementados.");
        drawText(28, 292, 1, muted, "Nenhum arquivo do Aurora ou DashLaunch e alterado.");
    } else if (app.page == Page::Connect) {
        drawText(28, 158, 2, green, "TRANSFERENCIA PELA REDE LOCAL");
        drawText(28, 208, 1, white, "STATUS: NAO CONFIGURADO");
        drawText(28, 244, 1, muted, "Protocolo, endereco IP e validacao ainda precisam ser implementados.");
        drawText(28, 292, 1, red, "ESTA VERSAO NAO ENVIA NEM RECEBE ARQUIVOS.");
    } else if (app.page == Page::Cloud) {
        drawText(28, 158, 2, green, "SERVICOS DE JOGOS NA NUVEM");
        drawText(28, 208, 1, white, "XBOX CLOUD GAMING");
        drawText(28, 240, 1, muted, "Cliente oficial para Xbox 360 nao incluido.");
        drawText(28, 286, 1, white, "GEFORCE NOW / BOOSTEROID");
        drawText(28, 318, 1, muted, "Sem integracao funcional nesta versao.");
        drawText(28, 374, 1, red, "NAO E UM CLIENTE OFICIAL DE CLOUD GAMING.");
    } else if (app.page == Page::Profile) {
        drawText(28, 158, 2, green, "JOGADOR");
        drawText(28, 208, 1, white, "PERFIL LOCAL DE DEMONSTRACAO");
        drawText(28, 244, 1, muted, "Nenhuma conta Microsoft esta conectada.");
        drawText(28, 292, 1, red, "NAO DIGITE SUA SENHA NESTE PROTOTIPO.");
    } else if (app.page == Page::Settings) {
        const char* items[] = {
            "TEMA ESCURO: ATIVADO",
            "DESTAQUE VERDE: ATIVADO",
            "LAYOUT: 16:9 / 1280x720",
            "CONTROLE: XBOX 360"
        };
        drawText(28, 158, 2, green, "APARENCIA");
        for (int i = 0; i < 4; ++i) {
            const int y = 214 + i * 48;
            drawText(42, y, 1, app.selected == i ? green : white, items[i]);
            if (app.selected == i) drawText(20, y, 1, green, ">");
        }
        drawText(28, 430, 1, muted, "A alterna a dica demonstrativa; nao altera o sistema.");
    }

    drawText(28, 620, 1, green, app.notice);
    if (app.showHint)
        drawText(28, 666, 1, muted, "A SELECIONAR   B INICIO   LB/RB TROCAR SECAO   BACK SAIR");
}

bool pressed(uint16_t current, uint16_t previous, uint16_t mask) {
    return (current & mask) != 0 && (previous & mask) == 0;
}

void handleInput(AppState& app, uint16_t buttons, uint16_t previous) {
    if (pressed(buttons, previous, INPUT_GAMEPAD_BACK)) {
        app.running = false;
        return;
    }
    if (pressed(buttons, previous, INPUT_GAMEPAD_B)) {
        app.page = Page::Home;
        app.selected = 0;
        setNotice(app, "VOLTANDO AO INICIO");
    }
    if (pressed(buttons, previous, INPUT_GAMEPAD_START))
        app.showHint = !app.showHint;

    if (pressed(buttons, previous, INPUT_GAMEPAD_DPAD_UP)) {
        if (app.page == Page::Home || app.page == Page::Settings)
            app.selected = (app.selected + 3) % 4;
        else
            changePage(app, -1);
    }
    if (pressed(buttons, previous, INPUT_GAMEPAD_DPAD_DOWN)) {
        if (app.page == Page::Home || app.page == Page::Settings)
            app.selected = (app.selected + 1) % 4;
        else
            changePage(app, 1);
    }
    if (pressed(buttons, previous, INPUT_GAMEPAD_DPAD_LEFT) ||
        pressed(buttons, previous, INPUT_GAMEPAD_LEFT_SHOULDER))
        changePage(app, -1);
    if (pressed(buttons, previous, INPUT_GAMEPAD_DPAD_RIGHT) ||
        pressed(buttons, previous, INPUT_GAMEPAD_RIGHT_SHOULDER))
        changePage(app, 1);
    if (pressed(buttons, previous, INPUT_GAMEPAD_A))
        activate(app);
}
} // namespace

int main() {
    xsdk_log_write("xse360: starting native xSDK dashboard prototype");
    const NTSTATUS splash = xsdk_splash_show(kSplashMs);
    if (!NT_SUCCESS(splash))
        xsdk_log_write("xse360: splash failed: 0x%08X", (unsigned)splash);

    NTSTATUS status = xsdk_gpu_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("xse360: xsdk_gpu_open failed: 0x%08X", (unsigned)status);
        return 1;
    }

    uint32_t width = 0, height = 0;
    status = xsdk_present_open(XSDK_DISPLAY_720P, kBuffers, kSwapInterval, &width, &height);
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("xse360: xsdk_present_open failed: 0x%08X", (unsigned)status);
        xsdk_gpu_close();
        return 1;
    }

    status = xsdk_text_open();
    if (!NT_SUCCESS(status)) {
        xsdk_log_write("xse360: xsdk_text_open failed: 0x%08X", (unsigned)status);
        xsdk_present_close();
        xsdk_gpu_close();
        return 1;
    }

    xsdk_log_write("xse360: display is %ux%u", (unsigned)width, (unsigned)height);
    AppState app;
    uint16_t previousButtons = 0;

    while (app.running) {
        INPUT_STATE input = {};
        if (XamInputGetState(0, 0, &input) != ERROR_SUCCESS)
            input = {};
        handleInput(app, input.gamepad.buttons, previousButtons);
        previousButtons = input.gamepad.buttons;

        uint32_t address = 0;
        status = xsdk_present_begin(&address, kBeginTimeoutMs);
        if (!NT_SUCCESS(status)) {
            xsdk_log_write("xse360: xsdk_present_begin failed: 0x%08X", (unsigned)status);
            break;
        }
        xsdk_gpu_set_target(width, height);
        drawPage(app);
        xsdk_gpu_resolve(address, width, height, rgb(13, 16, 22));
        xsdk_present_end();
    }

    xsdk_text_close();
    xsdk_present_close();
    status = xsdk_gpu_close();
    if (!NT_SUCCESS(status))
        xsdk_log_write("xse360: xsdk_gpu_close failed: 0x%08X", (unsigned)status);
    xsdk_log_write("xse360: ended");
    return 0;
}
