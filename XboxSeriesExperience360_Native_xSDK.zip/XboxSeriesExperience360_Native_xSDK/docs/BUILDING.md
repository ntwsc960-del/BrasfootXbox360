# Building the native Xbox Series Experience 360 prototype

1. On a Windows 10/11 PC, install WSL 2 and Debian.
2. Follow the official xSDK getting-started guide:
   https://github.com/xenosworks/xsdk/blob/main/docs/GETTING_STARTED.md
3. Build the xSDK toolchain and `libxsdk.a` as described in that guide.
4. Copy this project into Debian's Linux filesystem (not a Windows-mounted `/mnt/c` path if avoidable).
5. From the project directory, run:

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$HOME/xsdk/cmake/xsdk.cmake" \
  -DXSDK_TOOLCHAIN="$HOME/xsdk-gcc" \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build
```

The intended output is `build/XboxSeriesExperience360.xex`. This output has not been generated in this environment.

## Safe first test

Use a dedicated folder on the console and launch the XEX from Aurora's file manager. Do not replace Aurora, change DashLaunch settings, or write to NAND. If it fails, retrieve the log named `XboxSeriesExperience360.log` beside the XEX and keep the complete build output.
