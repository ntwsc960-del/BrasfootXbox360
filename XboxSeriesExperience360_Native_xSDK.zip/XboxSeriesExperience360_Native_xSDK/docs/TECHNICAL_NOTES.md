# Technical notes

This revision is based on the xSDK public APIs documented in:
- `include/xsdk/kernel.h`: controller button constants, `INPUT_STATE`, and `XamInputGetState`.
- `include/xsdk/gpu.h`: GPU initialization, target setup and resolve.
- `include/xsdk/present.h`: 720p presentation.
- `include/xsdk/text.h`: bitmap-font text rendering.
- `samples/template` and `samples/hello`: xSDK title lifecycle and controller loop.

The prior SDL-based project required a separately built SDL-xenon package and relied on a more complicated integration path. This native starter intentionally avoids that dependency so the first milestone is just one xSDK title.
